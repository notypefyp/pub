Hello, thank's for downloading SAC (Slime 'n Crates). 
If you want to change the resolution of game window, go to debug.json and change width, height.
But don't change the other things, it's automatically configured.