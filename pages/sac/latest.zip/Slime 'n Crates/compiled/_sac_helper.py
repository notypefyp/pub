# ! sac_helper.py
# Awesome Slime 'n Crates Helper/Compiler

import os, sys, time, json, urllib.parse, pygame

data = {}

class SACHelper:
    def Debug(self, inp):
        print(f'※ | {inp}')

    def DebugTrue(self, inp):
        print(f'✓ | {inp}')

    def DebugFalse(self, inp):
        print(f'✕ | {inp}')

    def DebugInfo(self, inp):
        print(f'ℹ️ | {inp}')

    def ClearScreen(self):
        os.system('clear' if not os.system.__name__ != 'nt' else 'cls')

class SACCompiler:
    def __init__(self, name):
        self.name = name

    def Compile(self):
        with open(f'addons/{self.name}.py', 'r') as f:
            structure = f.read()
        with open(f'compiled/{self.name}.sac', 'w') as f:
            structure_encoded = urllib.parse.quote(structure)
            f.write(f'{structure_encoded}')

    def DeCompile(self):
        with open(f'compiled/{self.name}.sac', 'r') as f:
            structure = f.read()
        with open(f'compiled/decompiled_{self.name}.py', 'w') as f:
            pre_structure = urllib.parse.unquote(structure)
            f.write(f'# Decompiled by SACCompiler\n\n{pre_structure}')